<div class="right_contents">
    <?=CONFIG($this->LAN)["culture_atricle"]?>
</div>